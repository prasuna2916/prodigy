let startTime = 0;
let elapsedTime = 0;
let timerInterval;
let running = false;

const display = document.getElementById('time-display');
const startStopBtn = document.getElementById('start-stop-btn');
const resetBtn = document.getElementById('reset-btn');

// Function to format time
function formatTime(ms) {
    let milliseconds = ms % 1000;
    let seconds = Math.floor((ms / 1000) % 60);
    let minutes = Math.floor((ms / (1000 * 60)) % 60);
    let hours = Math.floor((ms / (1000 * 60 * 60)) % 24);

    // Pad with leading zeros
    milliseconds = milliseconds.toString().padStart(3, '0');
    seconds = seconds.toString().padStart(2, '0');
    minutes = minutes.toString().padStart(2, '0');
    hours = hours.toString().padStart(2, '0');

    return `${hours}:${minutes}:${seconds}.${milliseconds}`;
}

// Function to start or stop the stopwatch
function startStop() {
    if (!running) {
        startTime = Date.now() - elapsedTime;
        timerInterval = setInterval(() => {
            elapsedTime = Date.now() - startTime;
            display.innerHTML = formatTime(elapsedTime);
        }, 10);
        startStopBtn.innerHTML = 'Stop';
        resetBtn.disabled = false;
        running = true;
    } else {
        clearInterval(timerInterval);
        startStopBtn.innerHTML = 'Start';
        running = false;
    }
}

// Function to reset the stopwatch
function reset() {
    clearInterval(timerInterval);
    elapsedTime = 0;
    display.innerHTML = '00:00:00.000';
    startStopBtn.innerHTML = 'Start';
    resetBtn.disabled = true;
    running = false;
}

// Event Listeners
startStopBtn.addEventListener('click', startStop);
resetBtn.addEventListener('click', reset);
